<?php 


function SearchBikes($search) {

    try{
        include('./config.php');

        $query = "SELECT bikeId as 'id', bikeName as 'name' from bike
        WHERE upper(bikeName) like upper(:search)";

        $select = $conn->prepare($query);
        $search = '%'. $search . '%';
        $select->bindParam(":search", $search, PDO::PARAM_STR);
        $select->execute();
        $result = $select->fetchAll(PDO::FETCH_CLASS, "bike");

        return $result;
    }
    catch(Exception $ex){
        echo $ex->getMessage();        
    }
}


function GetPersons() {

    try{
        include('./config.php');

        $query = "SELECT personId as 'id', concat_ws(' ', personFirstName, personLastName) as 'name' from person";

        $select = $conn->prepare($query);
        $select->execute();
        $result = $select->fetchAll(PDO::FETCH_CLASS, "person");

        return $result;
    }
    catch(Exception $ex){
        echo $ex->getMessage();        
    }
}


function NewRented($rented){

    try{
        include('./config.php');

        $query = "INSERT INTO rentedbikes (`bikeId`, `personId`, `rentedFrom`, `rentedUntil`) VALUES (:bikeId, :personId, :fromdate, :todate);";

        $select = $conn->prepare($query);
        
        $select->bindParam(":bikeId", $rented->bikeId, PDO::PARAM_INT);
        $select->bindParam(":personId", $rented->personId, PDO::PARAM_INT);
        $select->bindParam(":fromdate", $rented->dateFrom, PDO::PARAM_STR);
        $select->bindParam(":todate", $rented->dateTo, PDO::PARAM_STR);
        $select->execute();
        $id = $conn->lastInsertId();
        
        return $id;
    }
    catch(Exception $ex){
        echo $ex->getMessage();        
    }
}

/*
function GetKurstermin($id) {

    try{
        include('./config.php');

        $query = "SELECT kursId as 'id', kursname, terminbeginn, raumbezeichnung from kurs
        NATURAL JOIN termin
        NATURAL JOIN raum
        WHERE terminId = :id";

        $select = $conn->prepare($query);
        $select->bindParam(":id", $id, PDO::PARAM_INT);
        $select->execute();
        $result = $select->fetchAll(PDO::FETCH_CLASS, "kurstermin");

        return $result[0];
    }
    catch(Exception $ex){
        echo $ex->getMessage();        
    }
}
?>