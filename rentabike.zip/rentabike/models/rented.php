<?php 

class rented{
    public $bikeId;
    public $personId;
    public $dateFrom;
    public $dateTo;
}