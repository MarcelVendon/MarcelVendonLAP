<?php 

class bike{
    public $id;
    public $name;
}