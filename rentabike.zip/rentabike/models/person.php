<?php

class person{
    public $id;
    public $name;
}